# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '7507a42bec27ea8c500dfbcdeb3c72918b9a8ec2f53d16295de07f327a0adef2b3daf60503c64833de6e0e5b39f7e6581583fcf7bfb4d957a983423f4e9ce2ba'
